package labs.electicstoreadmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElecticStoreAdminApplicationTests {

    @Test
    void contextLoads() {
    }

}
