package labs.electicstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElecticStoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(ElecticStoreApplication.class, args);
    }

}
